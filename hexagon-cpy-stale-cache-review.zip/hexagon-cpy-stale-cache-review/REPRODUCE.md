# Hexagon CPY stale-cache reproduction and review data

Technical reference for manual review, not a pull-request description.

## Source and patch scope

- Repository: https://github.com/ggml-org/llama.cpp
- Device tests were run on base `2ca15f5404760548c39e7b92bd43116a09414a1a` (master, 2026-10-04).
- Changed file: `ggml/src/ggml-hexagon/htp/cpy-ops.c` only, 10 added lines (`cpy-invalidate.patch`).
- `cpy-ops.c` is byte-identical in `9d3aba6b5e10a6dd086bd0555bd12c00366a8916` (master, 2026-10-05), and the patch applies there unchanged.
- `diag-flushall.patch` is a diagnostic variant (whole data cache clean + invalidate before every op). It is not part of the proposed change.

## Mechanism to review

This explanation is inferred from graph routing and cache-maintenance experiments; it is not a captured stale-line snapshot.

Line numbers refer to `9d3aba6`.

1. Qwen3.5 (`src/models/delta-net-base.cpp:472`) and LFM2 (`src/models/lfm2.cpp:198`) build the conv input as `concat(conv_state, transposed tokens, dim 0)`. They then copy its last `d_conv - 1` columns back into the recurrent state with a CPY from a strided view into a 1D destination (`delta-net-base.cpp:483/508`, `lfm2.cpp:216`).
2. CONCAT: the transposed second source is not taken by `concat_dma` (`htp/concat-ops.c:290`). `concat_2d_f32_transposed` (`:37`, selected at `:362`) gathers both sources in VTCM and writes the conv input to DDR by DMA (`:114`).
3. CPY: the source view `[d_conv - 1, C]` has a row stride of `(d_conv - 1 + n) * 4` bytes. Shapes differ and the source is not contiguous, so `exec_cpy` takes the `else if (sametype)` branch (`htp/cpy-ops.c:505`). `cpy_thread_f32_reshape` (`:544`) then reads the source through the data cache.
4. The conv inputs of all layers of a ubatch share one region of the compute buffer. The previous layer's CPY read the same window and left those lines in the cache.
5. Before each op, `htp_tensor_flush_all` (`htp/main.c:1125`) runs `hex_l2flush` (`htp/hex-utils.h:45`, `Q6_dccleaninva_A` per line) on inputs that are marked dirty.
   - In our fork's experiments this did not remove the stale lines; `qurt_mem_cache_clean(range, QURT_MEM_CACHE_FLUSH_INVALIDATE, QURT_MEM_DCACHE)` did.
   - We have not established the hardware reason.
6. A whole-cache clean happens at the start and end of an op batch (`main.c:1201`, `:1257`). Dirty bytes, or dirty ranges evicted to make room, exceeding the 4 MiB full-flush threshold also cause a whole-cache flush within the batch. A batch holds up to 1280 ops (`ggml-hexagon.cpp:113`), which is usually the whole forward pass.
7. The CPY can therefore save parts of the previous layer's conv window. The next ubatch then starts from that state.
   - Whether it happens depends on how much other traffic passes through the cache between the two CPYs. This may explain its sensitivity to ubatch size and chip, and variation between runs.

The patch adds `cpy_invalidate_src()` and calls it before the two `exec_cpy` paths that read src0 through the cache (`:502`, `:549`). DMA paths are unchanged.
- Clean + invalidate is used, not invalidate alone, so that dirty lines written through the cache by earlier ops are not dropped.
- Extended (64-bit mapped) tensors are skipped because `qurt_addr_t` is 32-bit. On these two paths, `exec_cpy` sends them to DMA or rejects them. This does not describe every early return in `exec_cpy`. The direct single-element cache-load path is not covered by the patch.

## Builds

Use Linux, Android NDK r28b, Hexagon SDK 6.6.0.0 and Hexagon Tools 19.0.07. Set `ANDROID_NDK_ROOT`, `HEXAGON_SDK_ROOT` and `HEXAGON_TOOLS_ROOT`.

```bash
git clone https://github.com/ggml-org/llama.cpp.git llama.cpp
bash build-review-variants.sh ./llama.cpp ./cpy-review-builds
```

| Variant | Changes from the base |
|---|---|
| a | None |
| b | `cpy-invalidate.patch` |
| c | `diag-flushall.patch` (diagnostic upper bound) |

- The script builds `llama-perplexity`, `htp-v79` and `htp-v81` with OpenCL off, and saves revisions, diffs, logs and SHA-256 hashes. It was syntax checked but not run end to end.
- The recorded runs used equivalent builds with the default preset (OpenCL on). Only the skels differed between variants.

## Device run

Deploy each variant into its own directory with `llama-perplexity`, `build/bin/*.so` and `libggml-htp-v81.so`. Add the device's FastRPC libraries if the loader cannot find them. Use absolute paths in `LD_LIBRARY_PATH` and `ADSP_LIBRARY_PATH`.

Write a base once with variant c (or b):

```sh
LD_LIBRARY_PATH=$D/c/lib ADSP_LIBRARY_PATH=$D/c/lib $D/c/bin/llama-perplexity \
  -m Qwen3.5-4B-Q4_K_M.gguf -f text.txt -c 512 -b 512 -ub 22 --chunks 4 -t 4 \
  --device HTP0 -ngl 99 --kl-divergence-base base.kld
```

Then run the variants alternately, several times each, with `--kl-divergence-base base.kld --kl-divergence`, and compare "Mean PPL(Q)" and "Maximum KLD".

`run_kld.sh` does both steps on the device.
- Put the variants in `<dir>/a`, `<dir>/b` and `<dir>/c`, each with `bin/llama-perplexity` and `lib/` (the `*.so` files and `libggml-htp-v81.so`).
- The script copies the device's FastRPC and OpenCL libraries from `/vendor/lib64` next to them if they are missing.
- `ppl-text.txt` is the text used in the recorded runs: llama.cpp's own documentation, MIT licensed.

```sh
sh run_kld.sh <dir> Qwen3.5-4B-Q4_K_M.gguf ppl-text.txt 22 5 c
```

It prints one line per run: "Mean PPL(Q)", "Maximum KLD" and "Same top p". Variant a should vary from run to run; b and c should agree with the base at the reported metric precision. The packaged script now fails when an inference subprocess fails or a required metric is absent; the original recorded hardware runs predate this script correction.

- Matching displayed PPL, maximum KLD, and top-1 do not establish raw-logit bitwise equality. The KL base stores quantized log probabilities and the comparison omits the clipped low-probability tail.
- At ubatch 20 the base-writing pass and the comparison passes differ by a fixed amount (maximum KLD 0.000029) for every variant, including c. Compare comparison runs with each other, not only with the base.

## Recorded observations

- Device: OnePlus 15 (Snapdragon 8 Elite Gen 5, Hexagon v81, Android 16).
- Model: Qwen3.5-4B converted from the official weights and quantized to Q4_K_M (includes MTP layers).
- Text: llama.cpp's own docs, at least 4 x 512 tokens.
- Base written by c; ubatch 22; a, b and c run 10 times each in alternation:

| Variant | Matching reported base metrics | Mean PPL(Q) over 10 runs | Maximum KLD |
|---|---|---|---|
| a | 0/10 | 10 different values, 7.040287 - 7.041751 | 0.000022 - 0.001457 |
| b | 10/10 | 7.040684 every run | 0 |
| c | 10/10 | 7.040684 every run | 0 |

Other groups:

| Device | Model | ubatch | Result |
|---|---|---|---|
| v81 | Qwen3.5-4B, base written by b | 22 | a deviated in 5 of 6 runs, b 6/6 matching reported metrics |
| v81 | LFM2-2.6B | 22 | a and b deterministic with matching reported metrics |

Cost, seconds per pass of 512 tokens on v81 with Qwen3.5-4B:

| ubatch | a | b | c |
|---|---|---|---|
| 22 (10 runs each) | 3.36 s | 3.37 s (+0.3%) | 3.65 s (+8.5%) |
| 1 (3 runs each, alternating) | 26.19 s | 26.33 s (+0.5%) | not run |

## Archive contents

The proposed and diagnostic patches, reproduction instructions and scripts, MIT-licensed test text, public Qwen3.5 per-run metrics and timing log, build hashes, and fresh CPY correctness results are included. The diagnostic patch is not part of the PR source diff.

Models, binaries, private-model records, device serial numbers and network addresses, and local control scripts are excluded. `REVIEW-NOTES.md` separates prior hardware runs from the fresh PR checks. `SHA256SUMS` covers all packaged files.
