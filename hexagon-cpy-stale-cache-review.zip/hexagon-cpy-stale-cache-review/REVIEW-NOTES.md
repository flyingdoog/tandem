# PR review updates, 2026-10-05

Submitted base: `a3a1c4747fdc0dcad40b3946108b89375d9a7d0e`. The CPY source is byte-identical to the prior device-test base `2ca15f5404760548c39e7b92bd43116a09414a1a` and to `9d3aba6b5e10a6dd086bd0555bd12c00366a8916`. The proposed diff remains 10 added lines in `cpy-ops.c` only.

- Fresh builds of Hexagon v73/v75/v79/v81 and Android `test-backend-ops` succeeded using NDK r28b, SDK 6.6.0.0 and Hexagon Tools 19.0.07, with OpenCL off.
- Fresh OnePlus 15 / v81 check: `test-backend-ops test -b HTP0 -o CPY`, compared with the CPU reference, exit 0, 138/138 tests passed. The log and build hashes are in `results/`. This tests the existing CPY cases; it is not a regression that recreates the inter-layer DMA buffer reuse.
- The code-style workflow's 153 model mappings passed. The submitted C blob meets EditorConfig and `git diff --check` passes. The full-platform CI suite was not run locally.
- The PPL/KLD reproduction and timing records use the prior `2ca15f54` builds. They were inspected during this review, not rerun on the new base. Their comparison metrics do not establish bitwise raw-logit equality.
- Documentation corrects the within-batch whole-cache flush threshold and the scalar/extended-tensor scope. The reason QuRT range maintenance fixes the reproduced drift while the existing dirty-range flush does not remains unestablished.
- `run_kld.sh` now checks inference exit status and all required comparison metrics. Its correction does not alter the previously recorded metrics. `results/script-checks.txt` records syntax and error-handling checks.

This is a selected public-data evidence package. The original local bundle is preserved. It excludes model weights, executables, private-model records, private keys, serial numbers and network addresses.
