# Validation record, 2026-10-05

Technical evidence for manual review, not a pull-request description.

Device-test base: `2ca15f5404760548c39e7b92bd43116a09414a1a`. Current master when this was written: `9d3aba6b5e10a6dd086bd0555bd12c00366a8916` (2026-10-05). `cpy-ops.c` is identical in both.

## Checks

- `cpy-invalidate.patch` applies to both commits. Applied to `9d3aba6`, the patched file matches the device-tested variant b byte for byte.
- Variants a, b and c were built with the upstream snapdragon preset, NDK r28b, Hexagon SDK 6.6.0.0 and Tools 19.0.07, for v79 and v81 together with `llama-perplexity` and `llama-server`. Host libraries and programs are byte-identical across the three variants; only the skels differ. Hashes are in `results/build-SHA256SUMS.txt`.
- First pass, 4-decimal perplexity:
  - Setup: two devices (v81, v79), the Qwen3.5 and LFM2 architectures, and several ubatches; a and b twice each. Private-model records are not packaged.
  - Result: all values agree. The only sign was one a run with a different uncertainty in the fifth decimal (v81, Qwen3.5 architecture, ubatch 22).
- Second pass, logits compared with `--kl-divergence`:
  - v81, Qwen3.5-4B, ubatch 22: a never reproduced the base (10 of 10 runs deviate, 10 distinct perplexities). b and c reproduced it in 10 of 10 runs each.
  - The other groups are in `REPRODUCE.md`. Deviations appeared only at ubatch 22 with the Qwen3.5 architecture on v81.
- Diagnostic comparison: b matches c (whole cache clean + invalidate before every op) on the reported PPL, maximum KLD, and top-1. These metrics do not establish bitwise equality of raw logits or rule out another op reading stale data without moving the metrics.
- Cost: +0.3% at ubatch 22 and +0.5% at ubatch 1 (about 0.27 ms per token), against +8.5% for c.
- Duplicate search, 2026-10-05: no report of this issue. #29739 (closed) proposed a VTCM/vgather path for the same short-row CONCAT and CPY as a performance change. If adopted, it would remove this CPY from the cache path; the fix here covers the generic path.

## Limits and remaining checks

- Reproduced in one configuration only. Untriggered configurations are not shown to be free of the hazard.
- The hardware reason why `dccleaninva` leaves the stale lines is not established.
- `test-backend-ops` was not run during the original variant-b recording. Fresh v81 CPY tests for the submitted code are recorded separately in `REVIEW-NOTES.md`. Full-platform CI was not run locally.
- The text was llama.cpp documentation, not wikitext-2.
- Device runs used `2ca15f54`. Other HTP files may differ in `9d3aba6`.
- `build-review-variants.sh` was syntax checked, not run end to end.

The contributor still needs to review the source personally, disclose meaningful AI assistance, and write their own submission text under the repository's contribution rules.
