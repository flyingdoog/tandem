#!/system/bin/sh
# On-device check for the Hexagon CPY stale-cache issue (see REPRODUCE.md).
# usage: sh run_kld.sh <dir> <model.gguf> <text.txt> [ubatch=22] [runs=5] [base variant=c]
#   <dir> holds one subdirectory per variant: a (as published), b (cpy-invalidate.patch), c (diag-flushall.patch),
#   each with bin/llama-perplexity and lib/ (the *.so files and libggml-htp-v81.so). Missing variants are skipped.
# The base variant writes the KL-divergence base once; then every variant runs <runs> times in turn against it.
# Matching displayed metrics do not prove raw-logit bitwise equality.
D=$1; M=$2; T=$3; UB=${4:-22}; N=${5:-5}; BV=${6:-c}
if [ -z "$D" ] || [ ! -f "$M" ] || [ ! -f "$T" ]; then
    echo "usage: sh run_kld.sh <dir> <model.gguf> <text.txt> [ubatch=22] [runs=5] [base variant=c]"
    exit 2
fi
D=$(cd "$D" && pwd)   # the Android 16 linker ignores relative LD_LIBRARY_PATH entries
[ -d "$D/$BV" ] || { echo "base variant $BV not found in $D"; exit 2; }
VARIANTS=""
for v in a b c; do
    [ -d "$D/$v" ] || continue
    VARIANTS="$VARIANTS $v"
    # FastRPC and OpenCL runtime libraries from the device, next to the package libraries (if not there yet)
    for f in libcdsprpc.so libvmmem.so vendor.qti.hardware.dsp-V1-ndk.so libOpenCL.so libOpenCL_adreno.so; do
        [ -f "$D/$v/lib/$f" ] || cp "/vendor/lib64/$f" "$D/$v/lib/" 2> /dev/null
    done
    chmod 755 "$D/$v/bin/"* 2> /dev/null
done

run() {  # run <variant> <extra args...>
    v=$1; shift
    LD_LIBRARY_PATH="$D/$v/lib" ADSP_LIBRARY_PATH="$D/$v/lib" "$D/$v/bin/llama-perplexity" -m "$M" -f "$T" \
        -c 512 -b 512 -ub "$UB" --chunks 4 -t 4 --device HTP0 -ngl 99 "$@" 2>&1
}

echo "== $(date '+%F %T') ubatch $UB, base from $BV, variants:$VARIANTS, $N runs each"
if ! run "$BV" --kl-divergence-base "$D/base.kld" > "$D/base.log"; then
    echo "base inference failed:"; tail -5 "$D/base.log"; exit 1
fi
grep -E "Final estimate" "$D/base.log" || { echo "base run failed:"; tail -5 "$D/base.log"; exit 1; }
i=1
while [ $i -le "$N" ]; do
    for v in $VARIANTS; do
        if ! run "$v" --kl-divergence-base "$D/base.kld" --kl-divergence > "$D/$v$i.log"; then
            echo "$v$i inference failed:"; tail -5 "$D/$v$i.log"; exit 1
        fi
        for metric in 'Mean +PPL\(Q\) +:' 'Maximum KLD:' 'Same top p:'; do
            grep -E "$metric" "$D/$v$i.log" > /dev/null || {
                echo "$v$i missing metric: $metric"; tail -5 "$D/$v$i.log"; exit 1;
            }
        done
        echo "$v$i | $(grep -E 'Mean +PPL\(Q\) +:|Maximum KLD:|Same top p:' "$D/$v$i.log" | tr -s ' ' | tr '\n' ' ')"
    done
    i=$((i + 1))
done
rm -f "$D/base.kld"
echo "== done $(date '+%F %T'); full outputs in $D/*.log"
