#!/usr/bin/env bash
set -euo pipefail

# Usage: build-review-variants.sh <llama.cpp checkout> <new output directory>
# Builds a (as published), b (cpy-invalidate.patch) and c (diag-flushall.patch, diagnostic only) from the pinned base,
# each in its own clone. Set BASE to try another commit; the patches must apply to it.
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <llama.cpp checkout> <new output directory>" >&2
    exit 2
fi
: "${ANDROID_NDK_ROOT:?Set ANDROID_NDK_ROOT}"
: "${HEXAGON_SDK_ROOT:?Set HEXAGON_SDK_ROOT}"
: "${HEXAGON_TOOLS_ROOT:?Set HEXAGON_TOOLS_ROOT}"

source_dir=$(cd "$1" && pwd)
material_dir=$(cd "$(dirname "$0")" && pwd)
base=${BASE:-2ca15f5404760548c39e7b92bd43116a09414a1a}
git -C "$source_dir" cat-file -e "$base^{commit}"
if [ -e "$2" ]; then
    echo "Output directory already exists; choose a new directory." >&2
    exit 2
fi
mkdir -p "$2"
out_dir=$(cd "$2" && pwd)

for variant in a b c; do
    tree="$out_dir/$variant"
    git clone --quiet --no-hardlinks --no-checkout "$source_dir" "$tree"
    git -C "$tree" checkout --quiet --detach "$base"
    case "$variant" in
        b) git -C "$tree" apply "$material_dir/cpy-invalidate.patch" ;;
        c) git -C "$tree" apply "$material_dir/diag-flushall.patch" ;;
    esac
    (
        cd "$tree"
        cp docs/backend/snapdragon/CMakeUserPresets.json .
        git rev-parse HEAD > source-revision.txt
        git diff --binary > source-changes.patch
        cmake --preset arm64-android-snapdragon-release -B build -G Ninja -DGGML_OPENCL=OFF > configure.log 2>&1
        cmake --build build -j "${BUILD_JOBS:-4}" --target llama-perplexity htp-v79 htp-v81 > build.log 2>&1
        sha256sum ggml/src/ggml-hexagon/htp/cpy-ops.c ggml/src/ggml-hexagon/htp/main.c build/bin/llama-perplexity \
            build/ggml/src/ggml-hexagon/libggml-htp-v79.so build/ggml/src/ggml-hexagon/libggml-htp-v81.so > SHA256SUMS
    )
    echo "$variant: built; logs and hashes in $tree"
done
