# Hexagon work-queue reproduction and review data

Technical reference for manual review, not a pull-request description.

## Source and patch scope

- Repository: https://github.com/ggml-org/llama.cpp
- Base: `4364bf7232e65c34eca8d9500c5464389662de6b`.
- Changed file: `ggml/src/ggml-hexagon/htp/work-queue.c` only.
- Apply `work-queue-pr.patch` to that base. Test hooks are separate patches and are not part of the proposed source change.
- Relative to the previously tested `work-queue-fix.patch`, the proposed patch changes only comments and alignment. Task scheduling and memory orders are identical.

## Four independent builds

Use Linux, Android NDK r28b, Hexagon SDK 6.6.0.0 and Hexagon Tools 19.0.07. Follow the upstream Snapdragon backend setup for those dependencies. Set `ANDROID_NDK_ROOT`, `HEXAGON_SDK_ROOT` and `HEXAGON_TOOLS_ROOT` to your installations.

```bash
git clone https://github.com/ggml-org/llama.cpp.git llama.cpp
bash build-review-variants.sh ./llama.cpp ./queue-review-builds
```

The script requires a new output directory and checks out the pinned commit independently for each variant:

| Variant | Changes from the base |
|---|---|
| vanilla | None |
| repro | Original queue plus `work-queue-race-repro.patch` |
| fixed-repro | Proposed fix plus `work-queue-pr-race-repro.patch` |
| fixed | Proposed fix only |

Both repro builds prepend `#define WORK_QUEUE_RACE_TEST 1000` to the C source. This makes the compiler macro reach the DSP's separate CMake build; an unrelated top-level CMake cache variable is insufficient. The hook inserts pauses after wakeup, between the worker's sequence-number read and task lookup. It widens an existing interleaving without changing task payloads.

Each build saves the base revision, exact diff, compiler logs and SHA-256 hashes. The script has been syntax checked; the four-build driver itself has not been run end to end in this review. See `VALIDATION.md` for the independently performed checks.

## Device run

Use separate directories for all four variants. For each, deploy:

- `build/bin/llama-bench` into `bin/`.
- Required `build/bin/*.so` into `lib/`.
- `build/ggml/src/ggml-hexagon/libggml-htp-v79.so` into `lib/`.
- Device-compatible FastRPC runtime libraries, if not accessible through the device's normal loader paths.

In each variant's directory, run the same model and options:

```sh
LD_LIBRARY_PATH="$PWD/lib" ADSP_LIBRARY_PATH="$PWD/lib" \
  timeout 180 bin/llama-bench -m /path/to/Qwen3.5-4B-Q4_0.gguf \
  -dev HTP0 -ngl 99 -t 4 -p 128 -n 32 -r 2 > run.log 2>&1
status=$?
printf 'exit=%s\n' "$status"
```

Use a quiet device and keep thermal conditions comparable. The recorded device was a OnePlus 13T, Snapdragon 8 Elite / Hexagon v79, Android 16. Other DSP generations were not run on hardware in the recorded experiments.

On this upstream base, the amplified original aborted with exit 134 and `dspqueue_read failed: 0x0000002e`. A timeout (typically exit 124 or 137) is another possible symptom; it is not independently sufficient to identify this race. Inspect the error and backtrace. A fork that retries interrupted queue reads instead of aborting can wait indefinitely.

## Previously recorded device observations

These logs were collected before this review, on the pinned upstream base. They are distinct from new compilation and host-side validation.

| Variant | Exit | pp128, tok/s | tg32, tok/s |
|---|---:|---:|---:|
| vanilla | 0 | 669.88 +/- 0.92 | 14.47 +/- 0.08 |
| repro | 134 | Aborted | Aborted |
| fixed-repro | 0 | 658.80 +/- 5.94 | 14.58 +/- 0.06 |
| fixed | 0 | 665.20 +/- 2.83 | 14.38 +/- 0.06 |

Only two benchmark repetitions were used. Fixed vs vanilla differs by approximately -0.70% for prefill and -0.62% for decode. This small sample shows similar measured throughput; it is not proof of performance equivalence.

Separate fork tests completed 120 requests per fixed configuration with identical predictions. Those used other performance patches and a private fine-tuned model, so they are supplementary evidence, not a clean upstream regression test. Private request/response data is excluded from the review archive.

The same `0x2e` appears in issues #26123 and #22208, but a matching error code does not establish a common cause. This contribution does not claim to fix either issue.

## Protocol to review

The producer completes a task's barrier before publishing the next task. Therefore only the newest task can still need a given worker. `n_pub` identifies task publications independently of wakeups; each worker remembers its last handled publication. Task fields are atomic because a nonparticipant can lag while a slot is reused. The release fence before slot reuse and the acquire fence after field reads make the second `n_pub` read reject a stale snapshot. Participating workers keep their task alive until their barrier decrement.

The counters remain 32-bit. A worker missing an entire 2^32 publications is an ABA boundary; merely crossing UINT_MAX while processing tasks normally is not the issue. The existing wakeup sequence counter has a related full-cycle limitation. This patch does not redesign that boundary.

## Public archive contents

The archive contains the source fix, separate reproduction hooks, this reference, a generic build driver, sanitized upstream benchmark logs, and local validation material. It excludes models, binaries, private prompts and predictions, device serial numbers, local SSH configuration and device-control scripts. Build paths in copied logs may be replaced with placeholders. Original local logs remain unchanged.
