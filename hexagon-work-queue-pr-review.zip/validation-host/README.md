# Hexagon work-queue host regression

This is a local validation artifact, not a proposed upstream test. It runs actual
copies of the old and patched `work-queue.c` with pthread/QURT compatibility stubs
and controlled scheduling hooks. Original source files are not modified.

## Reproduce

To regenerate the instrumented copies, run `python prepare.py /path/to/old/work-queue.c /path/to/fixed/work-queue.c /path/to/work-queue.h`. It inserts the hooks described below without changing the inputs. The generated source copies are included so the test can also run without the original checkouts.

On a Linux host with GCC and pthread support, copy all `.c`, `.h`, and `run.sh`
files to an isolated directory, then run:

```sh
bash run.sh
```

Actual execution used `<host-validation-root>` on the existing build
VM and GCC 13.3.0 (Ubuntu 24.04). `run.sh` compiles both variants with
`-std=c11 -O2 -Wall -Wextra -Werror -pthread`. Each executable has a 45-second
timeout. Old implementation failure is expected and checked as exit status 42;
patched implementation must finish with status 0. `results.txt` contains raw output.

## What is checked

1. **Deterministic duplicate-callback reproduction.** Pause worker 1 immediately
   after it reads the wakeup sequence number 1. Publish a two-participant task,
   advancing the sequence to 2. The main-thread callback releases worker 1 and
   remains in flight while that worker handles the task and loops twice. The old
   implementation handles the same task again on observing sequence 2, so the
   callback reports a duplicate and exits 42 before barrier underflow can hang
   the test. The patched implementation remembers the publication and performs
   the callback exactly once. This hook is inserted into both source variants.
2. **Lagging non-participant and reused slots.** In the patched version, pause
   worker 3 after selecting publication 1's slot, before loading its fields.
   Run four tasks with two participants and capacity 2, reusing the selected slot
   twice. Release the worker and then run a four-participant task. Check callback
   metadata, exactly one invocation per participant, zero non-participant
   invocations, and visible callback output. Alternate callback pointers and data
   between tasks to exercise field reuse.
3. **36,000 task stress cases.** Total queue threads are 2, 4, 8, and 10; ring
   capacities are 2, 4, and 8. Every participant count from 1 through the total is
   exercised, with callback multiplicity and output visibility checked on each
   task. Suspend/wakeup is exercised 360 times, each after observing at least one
   worker enter the futex wait shim. Cleanup is also invoked after suspension.

## Limits

This is a Linux CPU test of the queue protocol, not a DSP or HVX test. The shim
uses pthreads and Linux private futexes, ignores QURT priority/stack attributes,
and substitutes `sched_yield` for `hex_pause`. Passing on this host does not prove
all weak-memory executions are correct, certify QURT ABI compatibility, or replace
compilation and execution with the Hexagon SDK/device. Sequence-counter wraparound
is not exercised. The source instrumentation exists only in generated host copies.

## Validated source SHA-256

* Old: `E12A0175E890C2C732BEC6F338C597527D0548DA4F6FE09C7AEB0816F766D419`
* Final fixed source, LF-normalized (also the DSP build input): `7c38249dfc6b785fe873960dfbba4fec4815c946e3c6c360aa55505457e679c2`
* Instrumented old host copy: `6362ab8c1069f387f0047bbc9e42dab571924e9ec09a416a8655fd107059f954`
* Instrumented final fixed host copy: `3533b4c3a0055f527e9fdbfe4667f465431beef6b313649a152afd563bbd8f63`
