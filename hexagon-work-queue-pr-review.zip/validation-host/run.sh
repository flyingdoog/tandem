#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
gcc --version | head -1
gcc -std=c11 -O2 -Wall -Wextra -Werror -pthread -I. -DOLD_QUEUE harness.c -o old-regression
gcc -std=c11 -O2 -Wall -Wextra -Werror -pthread -I. harness.c -o fixed-regression
set +e
./old-regression
old_status=$?
set -e
printf 'old-regression exit=%s (expected 42)\n' "$old_status"
test "$old_status" -eq 42
./fixed-regression
printf 'fixed-regression exit=0\n'
