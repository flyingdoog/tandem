"""Create host-only copies with scheduling hooks; original source files are untouched."""
from pathlib import Path
import argparse
import shutil

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("old_source", type=Path)
parser.add_argument("fixed_source", type=Path)
parser.add_argument("header", type=Path)
args = parser.parse_args()
for variant, source_path in [("old", args.old_source), ("fixed", args.fixed_source)]:
    source = source_path.read_text()
    marker = "        unsigned int seqn = atomic_load_explicit(&q->seqn, memory_order_acquire);"
    assert source.count(marker) == 1
    source = source.replace(marker, marker + "\n        test_after_seqn(me->id, seqn);")
    # This second hook forces a non-participant to lag across ring-slot reuse.
    if variant == "fixed":
        marker = "        work_queue_func_t func = atomic_load_explicit(&task->func, memory_order_relaxed);"
        assert source.count(marker) == 1
        source = source.replace(marker, "        test_before_fields(me->id, pub);\n" + marker)
    (HERE / (variant + "-queue.c")).write_text(source, newline="\n")
shutil.copyfile(args.header, HERE / "work-queue.h")
print("Created host-only source copies with controlled scheduling hooks.")
