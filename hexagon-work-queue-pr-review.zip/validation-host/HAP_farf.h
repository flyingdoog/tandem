#define FARF(...) ((void)0)
