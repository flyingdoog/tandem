#ifndef HOST_QURT_H
#define HOST_QURT_H
#include <pthread.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <linux/futex.h>
#include <unistd.h>
typedef pthread_t qurt_thread_t;
typedef struct { int unused; } qurt_thread_attr_t;
static inline void qurt_thread_attr_init(qurt_thread_attr_t *a) { (void)a; }
static inline void qurt_thread_attr_set_stack_addr(qurt_thread_attr_t *a, void *p) { (void)a; (void)p; }
static inline void qurt_thread_attr_set_stack_size(qurt_thread_attr_t *a, unsigned n) { (void)a; (void)n; }
static inline void qurt_thread_attr_set_name(qurt_thread_attr_t *a, const char *n) { (void)a; (void)n; }
static inline void qurt_thread_attr_set_priority(qurt_thread_attr_t *a, int p) { (void)a; (void)p; }
static inline int qurt_thread_get_priority(qurt_thread_t t) { (void)t; return 1; }
static inline qurt_thread_t qurt_thread_get_id(void) { return pthread_self(); }
struct host_start { void (*function)(void *); void *argument; };
static void *host_trampoline(void *p) {
    struct host_start start = *(struct host_start *)p;
    free(p);
    start.function(start.argument);
    return NULL;
}
static inline int qurt_thread_create(qurt_thread_t *t, qurt_thread_attr_t *a, void (*f)(void *), void *p) {
    (void)a;
    struct host_start *s = malloc(sizeof(*s));
    if (!s) return 12;
    *s = (struct host_start){f, p};
    int error = pthread_create(t, NULL, host_trampoline, s);
    if (error) free(s);
    return error;
}
static inline int qurt_thread_join(qurt_thread_t t, int *status) { *status = 0; return pthread_join(t, NULL); }
static atomic_uint host_futex_waits;
static inline void qurt_futex_wait(atomic_uint *p, unsigned value) {
    atomic_fetch_add(&host_futex_waits, 1);
    syscall(SYS_futex, p, FUTEX_WAIT_PRIVATE, value, NULL, NULL, 0);
}
static inline void qurt_futex_wake(atomic_uint *p, unsigned n) {
    syscall(SYS_futex, p, FUTEX_WAKE_PRIVATE, n, NULL, NULL, 0);
}
#endif
