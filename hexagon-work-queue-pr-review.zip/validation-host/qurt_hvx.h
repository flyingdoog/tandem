/* Host-only test: no HVX instructions are exercised. */
