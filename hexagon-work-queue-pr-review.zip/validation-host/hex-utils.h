#ifndef HOST_HEX_UTILS_H
#define HOST_HEX_UTILS_H
#include <stdint.h>
#include <stddef.h>
#include <sched.h>
#define HEX_L2_LINE_SIZE 128
static inline void hex_pause(void) { sched_yield(); }
static inline uint32_t hex_ceil_pow2(uint32_t n) { uint32_t p=1; while(p<n) p <<= 1; return p; }
static inline size_t hex_align_up(size_t n, size_t a) { return (n+a-1)&~(a-1); }
#endif
