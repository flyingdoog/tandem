#define _GNU_SOURCE
#include <assert.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sched.h>

static atomic_uint mode, held, release_worker, checked, passes, lag_held;
#ifndef OLD_QUEUE
static atomic_uint lag_release, lag_resumed;
#endif
static void wait_flag(atomic_uint *flag) {
    while (!atomic_load(flag)) sched_yield();
}
static void test_after_seqn(unsigned id, unsigned seqn) {
    if (atomic_load(&mode) != 1 || id != 1) return;
    if (seqn == 1 && !atomic_load(&held)) {
        atomic_store(&held, 1);
        wait_flag(&release_worker);
    } else if (seqn >= 2 && atomic_load(&held)) {
        if (atomic_fetch_add(&passes, 1) >= 1) atomic_store(&checked, 1);
    }
}
#ifndef OLD_QUEUE
static void test_before_fields(unsigned id, unsigned pub) {
    if (atomic_load(&mode) == 2 && id == 3 && pub == 1) {
        atomic_store(&lag_held, 1);
        wait_flag(&lag_release);
        atomic_store(&lag_resumed, 1);
    }
}
#include "fixed-queue.c"
#else
#include "old-queue.c"
#endif

typedef struct {
    unsigned expected_n;
    unsigned value;
    atomic_uint calls[WORK_QUEUE_MAX_N_THREADS];
    unsigned outputs[WORK_QUEUE_MAX_N_THREADS];
} job_t;

static void count_job(unsigned n, unsigned id, void *data) {
    job_t *job = data;
    if (n != job->expected_n || id >= n) {
        fprintf(stderr, "FAIL: wrong callback metadata n=%u id=%u expected_n=%u\n", n, id, job->expected_n);
        fflush(stderr); _Exit(43);
    }
    unsigned count = atomic_fetch_add(&job->calls[id], 1) + 1;
    if (count != 1) {
        fprintf(stderr, "FAIL: duplicate callback worker=%u count=%u participants=%u\n", id, count, n);
        fflush(stderr); _Exit(42);
    }
    job->outputs[id] = job->value ^ id;
    if (atomic_load(&mode) == 1 && id == 0) {
        atomic_store(&release_worker, 1);
        wait_flag(&checked);
    }
    if (atomic_load(&mode) == 2 && id == 0 && job->value == 1) wait_flag(&lag_held);
}
#ifndef OLD_QUEUE
static void alternate_job(unsigned n, unsigned id, void *data) { count_job(n, id, data); }
#endif
static void check_job(job_t *job, unsigned total) {
    for (unsigned id=0; id<total; ++id) {
        assert(atomic_load(&job->calls[id]) == (id < job->expected_n ? 1u : 0u));
        if (id < job->expected_n) assert(job->outputs[id] == (job->value ^ id));
    }
}
static work_queue_t create_queue(unsigned threads, unsigned capacity, void **memory) {
    assert(posix_memalign(memory, work_queue_alignof(), work_queue_sizeof(threads, capacity, 65536)) == 0);
    work_queue_t queue = work_queue_init(*memory, threads, capacity, 65536);
    assert(queue);
    return queue;
}
static void duplicate_regression(void) {
    atomic_store(&mode, 1);
    void *memory;
    work_queue_t queue = create_queue(2, 2, &memory);
    work_queue_wakeup(queue);
    wait_flag(&held);
    job_t job = {.expected_n=2, .value=71};
    assert(work_queue_run_async(queue, count_job, &job, 2));
    atomic_store(&mode, 0);
    check_job(&job, 2);
    work_queue_free(queue); free(memory);
    puts("PASS: deterministic stale seqn snapshot executes each participant exactly once");
}
#ifndef OLD_QUEUE
static void reuse_regression(void) {
    atomic_store(&mode, 2);
    void *memory;
    work_queue_t queue = create_queue(4, 2, &memory);
    work_queue_wakeup(queue);
    job_t jobs[5] = {0};
    for (unsigned i=0; i<4; ++i) {
        jobs[i].expected_n = 2;
        jobs[i].value = i+1;
        assert(work_queue_run_async(queue, i%2 ? alternate_job : count_job, &jobs[i], 2));
        check_job(&jobs[i], 4);
    }
    atomic_store(&lag_release, 1);
    wait_flag(&lag_resumed);
    jobs[4].expected_n=4; jobs[4].value=5;
    assert(work_queue_run_async(queue, count_job, &jobs[4], 4));
    atomic_store(&mode, 0);
    for (unsigned i=0; i<5; ++i) check_job(&jobs[i], 4);
    work_queue_free(queue); free(memory);
    puts("PASS: lagging non-participant survives two ring-slot reuses and later participates");
}
static void stress_regression(void) {
    const unsigned totals[] = {2, 4, 8, 10};
    const unsigned capacities[] = {2, 4, 8};
    unsigned tasks=0, sleeps=0;
    for (unsigned t=0; t<4; ++t) for (unsigned c=0; c<3; ++c) {
        unsigned total=totals[t]; void *memory;
        work_queue_t queue=create_queue(total, capacities[c], &memory);
        work_queue_wakeup(queue);
        for (unsigned i=0; i<3000; ++i) {
            unsigned n=1+(i%(total));
            job_t job={.expected_n=n, .value=i+100};
            assert(work_queue_run_async(queue, i%2 ? alternate_job : count_job, &job, n));
            check_job(&job, total);
            ++tasks;
            if (i%100 == 99) {
                unsigned before=atomic_load(&host_futex_waits);
                work_queue_suspend(queue);
                while (atomic_load(&host_futex_waits) == before) sched_yield();
                ++sleeps;
                work_queue_wakeup(queue);
            }
        }
        work_queue_suspend(queue);
        work_queue_free(queue); free(memory);
    }
    printf("PASS: %u tasks; total threads={2,4,8,10}; all participant counts; capacities={2,4,8}; %u observed suspend/wakeup cycles\n", tasks, sleeps);
}
#endif
int main(void) {
    alarm(45);
    setvbuf(stdout, NULL, _IONBF, 0);
    duplicate_regression();
#ifndef OLD_QUEUE
    reuse_regression();
    stress_regression();
    puts("ALL HOST REGRESSIONS PASSED (pthread/QURT shim; not DSP validation)");
#endif
    return 0;
}
