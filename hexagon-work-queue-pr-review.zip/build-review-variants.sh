#!/usr/bin/env bash
set -euo pipefail

# Usage: build-review-variants.sh <llama.cpp checkout> <new output directory>
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <llama.cpp checkout> <new output directory>" >&2
    exit 2
fi
: "${ANDROID_NDK_ROOT:?Set ANDROID_NDK_ROOT}"
: "${HEXAGON_SDK_ROOT:?Set HEXAGON_SDK_ROOT}"
: "${HEXAGON_TOOLS_ROOT:?Set HEXAGON_TOOLS_ROOT}"

source_dir=$(cd "$1" && pwd)
material_dir=$(cd "$(dirname "$0")" && pwd)
base=4364bf7232e65c34eca8d9500c5464389662de6b
git -C "$source_dir" cat-file -e "$base^{commit}"
if [ -e "$2" ]; then
    echo "Output directory already exists; choose a new directory." >&2
    exit 2
fi
mkdir -p "$2"
out_dir=$(cd "$2" && pwd)

for variant in vanilla repro fixed-repro fixed; do
    tree="$out_dir/$variant"
    git clone --quiet --no-hardlinks --no-checkout "$source_dir" "$tree"
    git -C "$tree" checkout --quiet --detach "$base"
    case "$variant" in
        fixed|fixed-repro)
            git -C "$tree" apply "$material_dir/work-queue-pr.patch"
            ;;
    esac
    case "$variant" in
        repro)
            git -C "$tree" apply "$material_dir/work-queue-race-repro.patch"
            ;;
        fixed-repro)
            git -C "$tree" apply "$material_dir/work-queue-pr-race-repro.patch"
            ;;
    esac
    case "$variant" in
        repro|fixed-repro)
            # This source define also reaches the separately configured DSP build.
            sed -i '1i#define WORK_QUEUE_RACE_TEST 1000' "$tree/ggml/src/ggml-hexagon/htp/work-queue.c"
            ;;
    esac
    (
        cd "$tree"
        cp docs/backend/snapdragon/CMakeUserPresets.json .
        git rev-parse HEAD > source-revision.txt
        git diff --binary > source-changes.patch
        cmake --preset arm64-android-snapdragon-release -B build -G Ninja \
            -DGGML_OPENCL=OFF -DLLAMA_CURL=OFF > configure.log 2>&1
        cmake --build build -j "${BUILD_JOBS:-4}" --target llama-bench htp-v79 > build.log 2>&1
        sha256sum ggml/src/ggml-hexagon/htp/work-queue.c \
            build/bin/llama-bench build/ggml/src/ggml-hexagon/libggml-htp-v79.so > SHA256SUMS
    )
    echo "$variant: built; logs and hashes in $tree"
done
