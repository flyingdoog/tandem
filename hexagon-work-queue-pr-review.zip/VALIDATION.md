# Validation record, 2026-09-28

This is technical evidence for manual review, not a pull-request description.

Base: `4364bf7232e65c34eca8d9500c5464389662de6b`.

## Fresh checks

- The single-file patch applies to the base and passes `git diff --check`.
- After removing comments and whitespace, the final source matches the earlier device-tested fix.
- A deterministic host regression makes the original worker call the same task twice and exit 42. The fixed implementation exits 0.
- The host regression also covers a lagging nonparticipant across slot reuse, 36,000 tasks with different participant counts, total thread counts 2/4/8/10, ring capacities 2/4/8, and 360 suspend/wakeup cycles.
- The proposed patch compiled successfully for Hexagon v73, v75, v79 and v81, together with Android `llama-bench` and `test-backend-ops`.
- Build environment: Linux x86_64, Android NDK r28b, Hexagon SDK 6.6.0.0, Hexagon Tools 19.0.07. Official `arm64-android-snapdragon-release` preset, `GGML_OPENCL=OFF`, `LLAMA_CURL=OFF`, `LLAMA_BUILD_TESTS=ON`.
- Output hashes and sanitized compiler logs are included in `results/`. Original compiler logs remain local; build-directory paths alone were replaced in the copies.

## Existing hardware data

The four upstream `llama-bench` logs were already recorded on OnePlus 13T / v79 with a standard Qwen3.5-4B Q4_0 model. They were independently checked during this review, not rerun. The amplified old queue aborted with exit 134 / `0x2e`; both fixed variants completed. Full commands and the small-sample performance limits are in `REPRODUCE.md`.

## Limits and remaining checks

- The host harness uses pthread/QURT stubs, not the actual DSP scheduler or a weak-memory model checker.
- Only v79 has recorded hardware results; v73/v75/v81 were compile-checked only.
- No fresh device run, `test-backend-ops` execution, `llama-perplexity` or full-platform CI was performed during this review. The device was reserved by another experiment; it was not interrupted.
- The portable four-build driver was syntax-checked but not run end to end. Its separate fixed repro patch was checked against the proposed source.
- No timing claim beyond the two recorded repetitions is justified.
- The original `0x2e` reports in other issues have not been verified with this patch.
- Counter ABA after a worker misses a complete 2^32 publications is outside this patch and outside the regression coverage.

The contributor still needs to review the source personally, disclose meaningful AI assistance, and write their own submission text under the repository's contribution rules.
