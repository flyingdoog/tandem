# PR update validation, 2026-10-05

Submitted base: `a3a1c4747fdc0dcad40b3946108b89375d9a7d0e`. Submitted source commit: `69813deaefbb429750807e9f44cd488bc2879316`. The aggregate source diff is 5 additions / 5 deletions in `ggml/src/ggml-hexagon/htp/hex-utils.h` only. The previous CPY-specific change has been removed.

- Fresh builds of Hexagon v73/v75/v79/v81 and Android `test-backend-ops` succeeded with NDK r28b, SDK 6.6.0.0 and Hexagon Tools 19.0.07, OpenCL off. The built header hash matches the submitted Git blob. Build hashes are in `results/fresh-stride-build-SHA256SUMS.txt`.
- Fresh OnePlus 15 / v81 tests of the submitted stride patch: `test-backend-ops test -b HTP0 -o CPY`, `-o CONCAT`, and `-o SSM_CONV`, each exit 0, with CPU reference comparison. The tool reports 138/138, 52/52, and 45/45 tests passed. Unsupported cases are skipped by the tester (CPY 357, CONCAT 146, SSM_CONV 0); these counts are not all supported cases. The existing cases do not recreate inter-layer DMA buffer reuse.
- The PPL/KLD and timing records use the contributor's earlier `2ca15f54` builds. They were inspected, not rerun on the submitted base. The backend sources at `2ca15f54`, the submitted base, and the reviewed `806eee9` agree apart from this proposed patch.
- The new stride comparison alternates a/d/e/f for ten runs each. a and e have ten distinct PPL values each; d and f match the whole-cache reference on the reported PPL, maximum KLD, and top-1. These metrics do not establish raw-logit bitwise equality.
- SDK implementation audit: the range clean-and-invalidate function uses a 64-byte instruction stride followed by `syncht` in v68/v69/v73/v75/v79/v81, including PIC libraries. This supports the granularity explanation; it does not directly capture stale bytes or identify which cache level retains them. No proprietary SDK objects or disassembly are packaged.
- Range alignment remains 128 bytes and loop/worker blocks remain 512 bytes. Within-batch whole-cache maintenance above 4 MiB is documented.
- Source checks passed: 153 model mappings, changed-file EditorConfig, and Git diff checks. Reproduction scripts passed syntax and reporting-fixture checks, including inference failure, missing metrics, and an empty base file. These fixtures do not test DSP behavior.
- Full-platform CI and a new model PPL/KLD run on the submitted base were not run locally. v73/v75/v79 were compile-checked; the fresh device tests use v81.

This selected public-data package replaces the earlier evidence for the CPY-only mitigation. The original local bundle is preserved. Models, binaries, private-model records, credentials, device identifiers and network addresses are excluded.
