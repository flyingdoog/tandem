# Validation record, 2026-10-05

Technical evidence for manual review, not a pull-request description.

Device-test base: `2ca15f5404760548c39e7b92bd43116a09414a1a`. Current master when this was written: `806eee9841de5f2c20f9d43914117f157d2baacc` (2026-10-05). `ggml/src/ggml-hexagon` is identical in both.

## Root-cause evidence and isolation

1. **Symptom.** On v81 with Qwen3.5-4B at ubatch 22, as-published runs never reproduce a whole-cache-flush reference: 0 of 20 runs over two tests, with a different perplexity every run.
2. **The state CPY is the suspected stale-data reader.**
   - Variant b cleans and invalidates only the CPY source with QuRT before the copy. It matches the whole-cache variant c on reported PPL, maximum KLD, and top-1, 10/10. This does not establish raw-logit bitwise equality.
   - The other reader of the DMA-written conv input, SSM_CONV, reads by DMA.
3. **`hex_l2flush` uses 128-byte steps; QuRT uses 64-byte steps.**
   - QuRT implements `qurt_mem_cache_clean(..., QURT_MEM_CACHE_FLUSH_INVALIDATE, QURT_MEM_DCACHE)`, the call b uses, as a user-mode `dccleaninva` loop with a `0x40` stride followed by `syncht`.
   - The loop is in `qurt_mem_cache_clean_impl`, `qurt_cache_c.o` of `libqurt.a`, and is the same in Hexagon SDK 6.6.0.0 for v68, v69, v73, v75, v79 and v81.
   - Both implementations use `dccleaninva`; QuRT uses 64-byte steps and a trailing `syncht`. Alignment, loop structure, and calling context also differ.
4. **The 128-byte stride plus `syncht` still drifts.** Variant e adds a CPY-source flush using the original loop and a trailing `syncht`. It does not remove the reproduced drift.
5. **Stride test on the device** (`results/kld-qwen35-4b-ub22-stride.txt`). a, d, e and f ran 10 times each, alternating, against a base written by c:
   - e, an extra flush of the CPY source with `hex_l2flush` (128 bytes) + `syncht`: 0/10 matching reported base metrics, 10 distinct perplexities.
   - f, the same flush at 64 bytes + `syncht`: 10/10 matching reported base metrics.
   - d, only `hex_l2flush` stepped by 64 bytes with no CPY change: 10/10 matching reported base metrics.
   - a, as published: 0/10 matching reported base metrics.

   e and f differ in instruction stride, range alignment, and loop structure; both add the same trailing `syncht`. d changes only the generic flush stride, with no CPY change or added barrier, and removes the recorded drift.

## Checks

- **Applies and builds.** `l2flush-stride.patch` applies to `2ca15f54` and `806eee9`. Built from it, the v79 and v81 skels are byte-identical to the device-tested d.
- **Build set.** All variants were built with the upstream snapdragon preset, NDK r28b, Hexagon SDK 6.6.0.0 and Tools 19.0.07, for v79 and v81. Host libraries and programs are byte-identical across variants; only the skels differ. Hashes are in `results/build-SHA256SUMS.txt`.
- **No change on v79.** On a OnePlus 13T, Qwen3.5-4B at ubatch 22 with a base written by c, a, d, e and f each reproduced the base in 3/3 runs at the reported metric precision.
  - v79 does not show the fault, so this checks only that the changes leave results unchanged there.
- **Earlier passes:**
  - Other models and ubatches did not expose the drift in the earlier tests. Private-model records are not packaged.
  - KL comparisons on other models and ubatch sizes: deviations appeared only at ubatch 22 with the Qwen3.5 architecture on v81 (see `REPRODUCE.md`).
- **Cost of d:**
  - +1.1% at ubatch 22 (3.454 s to 3.493 s per pass of 512 tokens, 10 runs each);
  - no measurable change at ubatch 1: 27.01 s for a and 27.02 s for d per 512 tokens, 3 runs each, alternating, with a run-to-run spread of about Â±0.25 s.
- **Duplicate search, 2026-10-05:** no report of this issue.
  - #29739 (closed) proposed a VTCM/vgather path for the same short-row CONCAT and CPY as a performance change.
  - It would take this CPY off the cache path but would not change `hex_l2flush`.

## Limits and remaining checks

- **One configuration.** The fault was reproduced in one configuration only. Untriggered configurations are not shown to be free of it.
- **64-byte step from software, not a manual.** The 64-byte maintenance size is inferred from QuRT's implementation and the device results, not from a hardware manual.
  - Whether the surviving copy sits in L1 or L2 was not determined.
  - No direct comparison was made between a cache read and a DMA read of the window after the flush. The prediction is that mismatches fall only in bytes 64-127 of a 128-byte block.
- **Other ops not tested.** `hex_l2flush` serves every op. Other ops may have been reading stale halves in configurations not tested here; d changes their flush too.
  - Original model recordings did not include device `test-backend-ops`. Fresh checks of the submitted stride patch are recorded separately in `REVIEW-NOTES.md`. Full-platform CI was not run locally.
- **Test text.** The text was llama.cpp documentation, not wikitext-2.
- **Build script.** `build-review-variants.sh` was syntax checked, not run end to end.

The contributor still needs to review the source personally, disclose meaningful AI assistance, and write their own submission text under the repository's contribution rules.
