# Hexagon stale-cache reproduction and review data

Technical reference for manual review, not a pull-request description.

## Summary

`hex_l2flush` issues one `dccleaninva` per 128 bytes. In Hexagon SDK 6.6.0.0, QuRT's range clean-and-invalidate implementation uses a 64-byte stride for the same instruction, followed by `syncht`. Device comparisons indicate that the 128-byte stride can leave stale cache data behind after DMA buffer reuse.

On v81 with Qwen3.5-4B at ubatch 22, the generic 64-byte-stride patch matches the whole-cache reference on the reported PPL, maximum KLD, and top-1 in all ten runs. A CPY-source flush at 128 bytes plus `syncht` still drifts. These metrics do not establish raw-logit bitwise equality.

## Source and patch scope

- Repository: https://github.com/ggml-org/llama.cpp
- Device tests were run on base `2ca15f5404760548c39e7b92bd43116a09414a1a` (master, 2026-10-04).
- `ggml/src/ggml-hexagon` has not changed between that base and `806eee9841de5f2c20f9d43914117f157d2baacc` (master, 2026-10-05). All patches apply there unchanged.
- Proposed change: `l2flush-stride.patch`. It touches `ggml/src/ggml-hexagon/htp/hex-utils.h` only, with 5 lines added and 5 removed.
  - Its v79 and v81 skels are byte-identical to the device-tested variant d.
- Other patches in this archive are diagnostics or an earlier, narrower fix (see "Builds").

## Mechanism to review

The stale-read explanation is inferred from graph routing, SDK implementation, and cache-maintenance experiments. It is not a captured comparison of cache and DMA reads.

Line numbers refer to `806eee9`.

1. **Model side.**
   - Qwen3.5 (`src/models/delta-net-base.cpp:472`) and LFM2 (`src/models/lfm2.cpp:198`) build the conv input as `concat(conv_state, transposed tokens, dim 0)`.
   - They copy its last `d_conv - 1` columns back into the recurrent state with a CPY from a strided view into a 1D destination (`delta-net-base.cpp:483/508`, `lfm2.cpp:216`).
2. **CONCAT writes by DMA.**
   - The transposed second source is not taken by `concat_dma` (`htp/concat-ops.c:290`).
   - `concat_2d_f32_transposed` (`:37`, selected at `:362`) gathers both sources in VTCM and writes the conv input to DDR by DMA (`:114`).
3. **Readers of the conv input.**
   - SSM_CONV reads it by DMA (`htp/ssm-conv.c:242`, `:351`).
   - The state CPY reads it through the data cache:
     - the source view `[d_conv - 1, C]` has a row stride of `(d_conv - 1 + n) * 4` bytes;
     - shapes differ and the source is not contiguous, so `exec_cpy` takes the `else if (sametype)` branch (`htp/cpy-ops.c:505`);
     - `cpy_thread_f32_reshape` (`:544`) then copies with HVX unaligned loads.
4. **Shared buffer.** The conv inputs of all layers of a ubatch share one region of the compute buffer. The previous layer's CPY read the same window and left those lines in the cache.
5. **The per-op flush uses a 128-byte instruction stride.**
   - Before each op, `htp_tensor_flush_all` (`htp/main.c:1125`, `htp/htp-tensor.c:331`) flushes inputs that overlap a dirty range. The range used is the input's full span, so the view is covered.
   - The flush is `hex_l2flush` (`htp/hex-utils.h:45`), called directly or from `l2flush_multi_worker` (`htp-tensor.c:38`). It issues `Q6_dccleaninva_A` at `s, s + 128, s + 256, ...` (`HEX_L2_LINE_SIZE = 128`).
   - Qualcomm's own implementation of the same operation steps by 64 bytes:
     - `qurt_mem_cache_clean(addr, size, QURT_MEM_CACHE_FLUSH_INVALIDATE, QURT_MEM_DCACHE)` runs in user mode as `{ r2 = add(r2,#0x40); dccleaninva(r2) }` in a loop, followed by `syncht`;
     - this is `qurt_mem_cache_clean_impl` in `qurt_cache_c.o` of `libqurt.a`;
     - it is the same in Hexagon SDK 6.6.0.0 for computev68, v69, v73, v75, v79 and v81;
     - the same library's `dccleana` and `dcinva` loops also step by `0x40`;
     - check with `hexagon-llvm-objdump -d` on that object.
   - This supports a maintenance-granularity mismatch. Residual stale data in bytes 64-127 is the predicted mechanism; those bytes have not been directly captured.
6. **Whole-cache maintenance.**
   - A whole-cache clean happens at the start and end of an op batch (`main.c:1201`, `:1257`). Dirty bytes, or ranges evicted to make room, exceeding 4 MiB also trigger a whole-cache flush within the batch.
   - A batch holds up to 1280 ops (`ggml-hexagon.cpp:113`), which is usually the whole forward pass.
7. **Result.**
   - The CPY can save stale words from the previous layer's conv window, and the next ubatch starts from that state.
   - Whether stale lines are still present depends on how much other traffic passes through the cache between the two CPYs. This may explain its sensitivity to ubatch size and chip, and variation between runs.

**The proposed change** (`l2flush-stride.patch`):
- adds `HEX_DCACHE_OP_SIZE = 64` and makes `hex_l2flush` step by it.
- The callers still align ranges to 128 bytes, which is a multiple of 64. `HEX_L2_LINE_SIZE` keeps its other uses: alignment and chunking.
- Each flush issues twice as many `dccleaninva` operations.

## Builds

Use Linux, Android NDK r28b, Hexagon SDK 6.6.0.0 and Hexagon Tools 19.0.07. Set `ANDROID_NDK_ROOT`, `HEXAGON_SDK_ROOT` and `HEXAGON_TOOLS_ROOT`.

```bash
git clone https://github.com/ggml-org/llama.cpp.git llama.cpp
bash build-review-variants.sh ./llama.cpp ./review-builds          # all six variants
VARIANTS="a c d" bash build-review-variants.sh ./llama.cpp ./review-builds-min
```

| Variant | Changes from the base | Role |
|---|---|---|
| a | None | as published |
| b | `cpy-invalidate.patch` | earlier narrower fix: QuRT clean + invalidate of the CPY source only |
| c | `diag-flushall.patch` | diagnostic upper bound: whole data cache clean + invalidate before every op |
| d | `l2flush-stride.patch` | **proposed change** |
| e | `diag-cpy-flush128.patch` | diagnostic: b with the QuRT call replaced by `hex_l2flush` (128-byte stride) + `syncht` |
| f | `diag-cpy-flush64.patch` | diagnostic: the same as e at a 64-byte stride |

- e and f share the CPY-source scope and trailing `syncht`. e uses the original 128-byte-aligned block loop; f uses a 64-byte-aligned loop. The instruction stride, alignment, and loop structure differ. Both f and QuRT use a 64-byte instruction stride.
- The script builds `llama-perplexity`, `htp-v79` and `htp-v81` with OpenCL off, and saves revisions, diffs, logs and SHA-256 hashes. It was syntax checked but not run end to end.
- The recorded runs used equivalent builds with the default preset (OpenCL on). Only the skels differed between variants.
- d was recorded from a patch with the literal `64` in place of `HEX_DCACHE_OP_SIZE`. Its skels are byte-identical to those of `l2flush-stride.patch`.

## Device run

Deploy each variant into its own directory with `llama-perplexity`, `build/bin/*.so` and `libggml-htp-v81.so`. Add the device's FastRPC libraries if the loader cannot find them. Use absolute paths in `LD_LIBRARY_PATH` and `ADSP_LIBRARY_PATH`.

Write a base once with variant c:

```sh
LD_LIBRARY_PATH=$D/c/lib ADSP_LIBRARY_PATH=$D/c/lib $D/c/bin/llama-perplexity \
  -m Qwen3.5-4B-Q4_K_M.gguf -f text.txt -c 512 -b 512 -ub 22 --chunks 4 -t 4 \
  --device HTP0 -ngl 99 --kl-divergence-base base.kld
```

Then run the variants alternately, several times each, with `--kl-divergence-base base.kld --kl-divergence`. Compare "Mean PPL(Q)" and "Maximum KLD".

`run_kld.sh` does both steps on the device.
- Put the variants in `<dir>/a` ... `<dir>/f`, each with `bin/llama-perplexity` and `lib/` (the `*.so` files and `libggml-htp-v81.so`). Missing variants are skipped.
- The script copies the device's FastRPC and OpenCL libraries from `/vendor/lib64` next to them if they are missing.
- `ppl-text.txt` is the text used in the recorded runs: llama.cpp's own documentation, MIT licensed.

```sh
sh run_kld.sh <dir> Qwen3.5-4B-Q4_K_M.gguf ppl-text.txt 22 5 c
```

It prints one line per run: "Mean PPL(Q)", "Maximum KLD" and "Same top p".
- Expected: a and e vary from run to run; b, d and f match the base at the reported metric precision.
- Matching displayed PPL, maximum KLD, and top-1 do not establish raw-logit bitwise equality. The KL base stores quantized log probabilities, and the comparison omits the clipped low-probability tail.
- At ubatch 20, the base-writing pass and the comparison passes differ by a fixed amount (maximum KLD 0.000029) for every variant, including c. Compare comparison runs with each other, not only with the base.
- The packaged script now rejects inference failure and missing comparison metrics. The recorded device runs predate this correction; script reporting checks are in `results/script-checks.txt`.

## Recorded observations

- Device: OnePlus 15 (Snapdragon 8 Elite Gen 5, Hexagon v81, Android 16).
- Model: Qwen3.5-4B converted from the official weights and quantized to Q4_K_M (includes MTP layers).
- Text: llama.cpp's own docs, at least 4 x 512 tokens. ubatch 22. Base written by c.

**Stride test** (`results/kld-qwen35-4b-ub22-stride.txt`). a, d, e and f ran 10 times each, alternating:

| Variant | Matching reported base metrics | Mean PPL(Q) over 10 runs | Maximum KLD |
|---|---|---|---|
| a | 0/10 | 10 different values, 7.040082 - 7.041850 | 0.000056 - 0.001298 |
| d (proposed) | 10/10 | 7.040684 every run | 0 |
| e (CPY flush, 128 B + `syncht`) | 0/10 | 10 different values, 7.040485 - 7.041629 | 0.000001 - 0.001971 |
| f (CPY flush, 64 B + `syncht`) | 10/10 | 7.040684 every run | 0 |

**First test** (`results/kld-qwen35-4b-ub22.txt`). a, b and c ran 10 times each, alternating:

| Variant | Matching reported base metrics | Mean PPL(Q) over 10 runs | Maximum KLD |
|---|---|---|---|
| a | 0/10 | 10 different values, 7.040287 - 7.041751 | 0.000022 - 0.001457 |
| b | 10/10 | 7.040684 every run | 0 |
| c | 10/10 | 7.040684 every run | 0 |

**Other groups:**

| Device | Model | ubatch | Result |
|---|---|---|---|
| v81 | Qwen3.5-4B, base written by b | 22 | a deviated in 5 of 6 runs, b 6/6 matching reported metrics |
| v81 | LFM2-2.6B | 22 | a and b deterministic with matching reported metrics |
| v79 (OnePlus 13T) | Qwen3.5-4B, base written by c | 22 | a, d, e, f 3/3 matching reported metrics each (v79 does not show the fault; no change in results) |

**Cost**, in seconds per pass of 512 tokens on v81 with Qwen3.5-4B:

| ubatch | a | b | c | d (proposed) |
|---|---|---|---|---|
| 22, first test (10 runs each) | 3.36 s | 3.37 s (+0.3%) | 3.65 s (+8.5%) | â€“ |
| 22, stride test (10 runs each) | 3.454 s | â€“ | â€“ | 3.493 s (+1.1%) |
| 1, morning (3 runs each, alternating) | 26.19 s | 26.33 s (+0.5%) | not run | â€“ |
| 1, afternoon (3 runs each, alternating) | 27.01 s | â€“ | â€“ | 27.02 s (+0.1%, within the Â±0.25 s run-to-run spread) |

The rows ran at different times and phone temperatures; compare within a row. ubatch 1 runs use one chunk of 512 tokens (`results/upub1-p2.log`).

## Archive contents

The proposed `l2flush-stride.patch`, earlier CPY patch, diagnostic patches, reproduction scripts, MIT-licensed test text, public Qwen3.5 per-run metrics, timing records, and build hashes are included. `REVIEW-NOTES.md` separates recorded model runs from fresh checks of the submitted patch.

The source PR changes only `hex-utils.h`. Models, binaries, private-model records, proprietary SDK objects or disassembly, credentials, device serial numbers and network addresses, and local control scripts are excluded. `SHA256SUMS` covers all packaged files.
